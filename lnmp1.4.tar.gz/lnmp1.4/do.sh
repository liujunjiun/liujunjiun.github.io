cur_dir=$(pwd)
download_Mirror='http://soft.vpser.net'
nginx_modules_options=''
php_modules_options=''
mysql_data_dir='/usr/local/mysql/var'
mariaDB_data_dir='/usr/local/mariadb/var'
default_website_dir='/home/wwwroot/default'
enable_nginx_openssl='y'
mysql_Bin="/usr/local/mysql/bin/mysql"
mysql_Config="/usr/local/mysql/bin/mysql_config"
mysql_dir="/usr/local/mysql"
DB_Root_password="root"
installInnodb="y"
mysql55MAOpt="-DCMAKE_EXE_LINKER_FLAGS='-ljemalloc' -DWITH_SAFEMALLOC=OFF"
NginxMAOpt="--with-ld-opt='-ljemalloc'"
tar_cd()
{
    local Filename=$1
    local dirname=$2
    cd ${cur_dir}/src
    [[ -d "${dirname}" ]] && rm -rf ${dirname}
    echo "Uncompress ${Filename}..."
    tar zxf ${Filename}
    echo "cd ${dirname}..."
    cd ${dirname}
}
tarj_cd()
{
    local Filename=$1
    local dirname=$2
    cd ${cur_dir}/src
    [[ -d "${dirname}" ]] && rm -rf ${dirname}
    echo "Uncompress ${Filename}..."
    tar jxf ${Filename}
    echo "cd ${dirname}..."
    cd ${dirname}
}
startUp()
{
    init_name=$1
    echo "Add ${init_name} service at system startup..."
    if [ "$PM" = "yum" ]; then
        chkconfig --add ${init_name}
        chkconfig ${init_name} on
    elif [ "$PM" = "apt" ]; then
        update-rc.d -f ${init_name} defaults
    fi
}
download_files()
{
    local URL=$1
    local Filename=$2
    if [ -s "${Filename}" ]; then
        echo "${Filename} [found]"
    else
        echo "Notice: ${Filename} not found!!!download now..."
        wget -c --progress=bar:force --prefer-family=IPv4 ${URL}
    fi
}
echo ""
echo "press any key to install...or press Ctrl+c to cancel"
OLDCONFIG=`stty -g`
stty -icanon -echo min 1 time 0
dd count=1 2>/dev/null
stty ${OLDCONFIG}
Autoconf_version='autoconf-2.13'
Libiconv_version='libiconv-1.14'
LibMcrypt_version='libmcrypt-2.5.8'
Mcypt_version='mcrypt-2.6.8'
Mhash_version='mhash-0.9.9.9'
Freetype_version='freetype-2.7'
Curl_version='curl-7.51.0'
Pcre_version='pcre-8.39'
Jemalloc_version='jemalloc-4.3.1'
TCMalloc_version='gperftools-2.5'
Libunwind_version='libunwind-1.1'
Libicu4c_version='icu4c-58_1'
Boost_version='boost_1_59_0'
Openssl_version='openssl-1.0.2j'
Nginx_version='nginx-1.10.2'
Mysql_version='mysql-5.7.16'
php_version='php-7.1.0'
PhpMyAdmin_version='phpMyAdmin-4.6.5.1-all-languages'
APR_version='apr-1.5.2'
APR_Util_version='apr-util-1.5.4'
xcache_version='xcache-3.2.0'
ImageMagick_version='ImageMagick-7.0.3-8'
Imagick_version='imagick-3.4.3RC1'
ZendOpcache_version='zendopcache-7.0.5'
Redis_Stable_version='redis-3.2.5'
PHPRedis_version='redis-2.2.7'
Memcached_version='memcached-1.4.33'
Libmemcached_version='libmemcached-1.0.18'
PHPMemcached_version='memcached-2.2.0'
if ps aux | grep "yum" | grep -qv "grep"; then
	killall yum
elif ps aux | grep "apt-get" | grep -qv "grep"; then
	killall apt-get
fi
if grep -Eqi "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
	DISTRO='CentOS'
	PM='yum'
elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
	DISTRO='RHEL'
	PM='yum'
elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
	DISTRO='Aliyun'
	PM='yum'
elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
	DISTRO='Fedora'
	PM='yum'
elif grep -Eqi "Amazon Linux AMI" /etc/issue || grep -Eq "Amazon Linux AMI" /etc/*-release; then
	DISTRO='Amazon'
	PM='yum'
elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
	DISTRO='Debian'
	PM='apt'
elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
	DISTRO='Ubuntu'
	PM='apt'
elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
	DISTRO='Raspbian'
	PM='apt'
elif grep -Eqi "Deepin" /etc/issue || grep -Eq "Deepin" /etc/*-release; then
	DISTRO='Deepin'
	PM='apt'
else
	DISTRO='unknow'
fi
if [[ `getconf WORD_BIT` = '32' && `getconf LONG_BIT` = '64' ]] ; then
	Is_64bit='y'
else
	Is_64bit='n'
fi
## 先改变软件源
Ubuntu_deadline()
{
    vivid_deadline=`date -d "2016-2-24 00:00:00" +%s`
    precise_deadline=`date -d "2017-5-27 00:00:00" +%s`
    wily_deadline=`date -d "2016-7-22 00:00:00" +%s`
    yakkety_deadline=`date -d "2017-7-22 00:00:00" +%s`
    trusty_deadline=`date -d "2019-7-22 00:00:00" +%s`
    cur_time=`date  +%s`
    case "$1" in
        vivid)
            if [ ${cur_time} -gt ${vivid_deadline} ]; then
                echo "${cur_time} > ${vivid_deadline}"
                check_Old_Releases_URL vivid
            fi
            ;;
        precise)
            if [ ${cur_time} -gt ${precise_deadline} ]; then
                echo "${cur_time} > ${precise_deadline}"
                check_Old_Releases_URL precise
            fi
            ;;
        wily)
            if [ ${cur_time} -gt ${wily_deadline} ]; then
                echo "${cur_time} > ${wily_deadline}"
                check_Old_Releases_URL wily
            fi
            ;;
        yakkety)
            if [ ${cur_time} -gt ${yakkety_deadline} ]; then
                echo "${cur_time} > ${yakkety_deadline}"
                check_Old_Releases_URL yakkety
            fi
            ;;
        trusty)
            if [ ${cur_time} -gt ${trusty_deadline} ]; then
                echo "${cur_time} > ${trusty_deadline}"
                check_Old_Releases_URL trusty
            fi
            ;;
    esac
}
check_Old_Releases_URL()
{
    OR_Status=`wget --spider --server-response http://old-releases.ubuntu.com/ubuntu/dists/$1/Release 2>&1 | awk '/^  HTTP/{print $2}'`
    if [ ${OR_Status} != "404" ]; then
        echo "Ubuntu old-releases status: ${OR_Status}";
        Codename=$1
    fi
}
if grep -Eqi "10.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^10.10'; then
        Codename='maverick'
    elif grep -Eqi "11.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^11.04'; then
        Codename='natty'
    elif  grep -Eqi "11.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^11.10'; then
        Codename='oneiric'
    elif grep -Eqi "12.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^12.10'; then
        Codename='quantal'
    elif grep -Eqi "13.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^13.04'; then
        Codename='raring'
    elif grep -Eqi "13.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^13.10'; then
        Codename='saucy'
    elif grep -Eqi "10.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^10.04'; then
        Codename='lucid'
    elif grep -Eqi "14.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^14.10'; then
        Codename='utopic'
    elif grep -Eqi "15.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^15.04'; then
        Ubuntu_deadline vivid
    elif grep -Eqi "12.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^12.04'; then
        Ubuntu_deadline precise
    elif grep -Eqi "15.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^15.10'; then
        Ubuntu_deadline wily
    elif grep -Eqi "16.10" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^16.10'; then
        Ubuntu_deadline yakkety
    elif grep -Eqi "14.04" /etc/*-release || echo "${Ubuntu_version}" | grep -Eqi '^14.04'; then
        Ubuntu_deadline trusty
    fi
    if [ "${Codename}" != "" ]; then
        \cp /etc/apt/sources.list /etc/apt/sources.list.$(date +"%Y%m%d")
        cat > /etc/apt/sources.list<<EOF
deb http://mirrors.aliyun.com/ubuntu/ ${Codename} main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-security main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-updates main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-proposed main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-backports main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ trusty main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-security main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-updates main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-proposed main restricted universe multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-backports main restricted universe multiverse
deb http://mirrors.aliyun.com/ubuntu/ trusty restricted
deb-src http://mirrors.aliyun.com/ubuntu/ trusty restricted
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-updates restricted
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-updates restricted
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-backports restricted multiverse
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-backports restricted multiverse
deb http://mirrors.aliyun.com/ubuntu/ ${Codename}-security restricted
deb-src http://mirrors.aliyun.com/ubuntu/ ${Codename}-security restricted
EOF
    fi
echo "正在查看软件源"
cat /etc/apt/sources.list  && apt-get update
## 设置时区
echo "setting timezone..."
rm -rf /etc/localtime
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

echo "[+] installing ntp..."
apt-get install -y ntpdate
ntpdate -u pool.ntp.org
date
if [ -s /etc/ld.so.conf.d/libc6-xen.conf ]; then
    sed -i 's/hwcap 1 nosegneg/hwcap 0 nosegneg/g' /etc/ld.so.conf.d/libc6-xen.conf
fi

## 删除久包，安装依赖
echo "[-] apt-get remove packages..."
apt-get update -y
for removepackages in apache2 apache2-doc apache2-utils apache2.2-common apache2.2-bin apache2-mpm-prefork apache2-doc apache2-mpm-worker mysql-client mysql-server mysql-common mysql-server-core-5.5 mysql-client-5.5 php5 php5-common php5-cgi php5-cli php5-mysql php5-curl php5-gd;
do apt-get purge -y $removepackages; done
apt-get install killall && killall apache2
dpkg -l |grep apache
dpkg -P apache2 apache2-doc apache2-mpm-prefork apache2-utils apache2.2-common
dpkg -l |grep mysql
dpkg -P mysql-server mysql-common libmysqlclient15off libmysqlclient15-dev
dpkg -l |grep php
dpkg -P php5 php5-common php5-cli php5-cgi php5-mysql php5-curl php5-gd
apt-get autoremove -y && apt-get clean
echo "[+] Apt-get installing dependent packages..."
apt-get update -y
apt-get autoremove -y
apt-get -fy install
export DEBIAN_FRONTEND=noninteractive
apt-get install -y build-essential gcc g++ make
for packages in build-essential gcc g++ make cmake autoconf automake re2c wget cron bzip2 libzip-dev libc6-dev file rcconf flex vim bison m4 gawk less cpp binutils diffutils unzip tar bzip2 libbz2-dev libncurses5 libncurses5-dev libtool libevent-dev openssl libssl-dev zlibc libsasl2-dev libltdl3-dev libltdl-dev zlib1g zlib1g-dev libbz2-1.0 libbz2-dev libglib2.0-0 libglib2.0-dev libpng3 libjpeg62 libjpeg62-dev libjpeg-dev libpng-dev libpng12-0 libpng12-dev libkrb5-dev curl libcurl3 libcurl3-gnutls libcurl4-gnutls-dev libcurl4-openssl-dev libpq-dev libpq5 gettext libjpeg-dev libpng12-dev libxml2-dev libcap-dev ca-certificates debian-keyring debian-archive-keyring libc-client2007e-dev psmisc patch git libc-ares-dev libicu-dev e2fsprogs libxslt libxslt1-dev libc-client-dev;
do apt-get install -y $packages --force-yes; done

if [ -s /etc/selinux/config ]; then
	sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config
fi

echo "[+] downloading files..."
cd ${cur_dir}/src
download_files  ${download_Mirror}/lib/autoconf/${Autoconf_version}.tar.gz ${Autoconf_version}.tar.gz
download_files  ${download_Mirror}/web/libiconv/${Libiconv_version}.tar.gz ${Libiconv_version}.tar.gz
download_files  ${download_Mirror}/web/libmcrypt/${LibMcrypt_version}.tar.gz ${LibMcrypt_version}.tar.gz
download_files  ${download_Mirror}/web/mcrypt/${Mcypt_version}.tar.gz ${Mcypt_version}.tar.gz
download_files  ${download_Mirror}/web/mhash/${Mhash_version}.tar.bz2 ${Mhash_version}.tar.bz2
download_files  ${download_Mirror}/lib/freetype/${Freetype_version}.tar.bz2 ${Freetype_version}.tar.bz2
download_files  ${download_Mirror}/lib/curl/${Curl_version}.tar.bz2 ${Curl_version}.tar.bz2
download_files  ${download_Mirror}/web/pcre/${Pcre_version}.tar.bz2 ${Pcre_version}.tar.bz2
download_files  ${download_Mirror}/lib/jemalloc/${Jemalloc_version}.tar.bz2 ${Jemalloc_version}.tar.bz2
download_files  ${download_Mirror}/web/nginx/${Nginx_version}.tar.gz ${Nginx_version}.tar.gz
download_files  ${download_Mirror}/datebase/mysql/${Mysql_version}.tar.gz ${Mysql_version}.tar.gz
#download_files  ${download_Mirror}/datebase/mariadb/${mariadb_version}.tar.gz ${mariadb_version}.tar.gz
download_files  ${download_Mirror}/web/php/${php_version}.tar.bz2 ${php_version}.tar.bz2
download_files  ${download_Mirror}/datebase/phpmyadmin/${PhpMyAdmin_version}.tar.bz2 ${PhpMyAdmin_version}.tar.bz2
download_files  ${download_Mirror}/prober/p.tar.gz p.tar.gz

echo "[+] installing ${Autoconf_version}"
tar_cd ${Autoconf_version}.tar.gz ${Autoconf_version}
./configure --prefix=/usr/local/autoconf-2.13
make && make install
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Autoconf_version}

echo "[+] installing ${Libiconv_version}"
tar_cd ${Libiconv_version}.tar.gz ${Libiconv_version}
patch -p0 < ${cur_dir}/src/patch/libiconv-glibc-2.16.patch
./configure --enable-static
make && make install
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Libiconv_version}

echo "[+] installing ${LibMcrypt_version}"
tar_cd ${LibMcrypt_version}.tar.gz ${LibMcrypt_version}
./configure
make && make install
/sbin/ldconfig
cd libltdl/
./configure --enable-ltdl-install
make && make install
ln -sf /usr/local/lib/libmcrypt.la /usr/lib/libmcrypt.la
ln -sf /usr/local/lib/libmcrypt.so /usr/lib/libmcrypt.so
ln -sf /usr/local/lib/libmcrypt.so.4 /usr/lib/libmcrypt.so.4
ln -sf /usr/local/lib/libmcrypt.so.4.4.8 /usr/lib/libmcrypt.so.4.4.8
ldconfig
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${LibMcrypt_version}

echo "[+] installing ${Mcypt_version}"
tar_cd ${Mcypt_version}.tar.gz ${Mcypt_version}
./configure
make && make install
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Mcypt_version}

echo "[+] installing ${Mhash_version}"
tarj_cd ${Mhash_version}.tar.bz2 ${Mhash_version}
./configure
make && make install
ln -sf /usr/local/lib/libmhash.a /usr/lib/libmhash.a
ln -sf /usr/local/lib/libmhash.la /usr/lib/libmhash.la
ln -sf /usr/local/lib/libmhash.so /usr/lib/libmhash.so
ln -sf /usr/local/lib/libmhash.so.2 /usr/lib/libmhash.so.2
ln -sf /usr/local/lib/libmhash.so.2.0.1 /usr/lib/libmhash.so.2.0.1
ldconfig
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Mhash_version}

echo "[+] installing ${Freetype_version}"
tarj_cd ${Freetype_version}.tar.bz2 ${Freetype_version}
./configure --prefix=/usr/local/freetype
make && make install

cat > /etc/ld.so.conf.d/freetype.conf<<EOF
/usr/local/freetype/lib
EOF
ldconfig
ln -sf /usr/local/freetype/include/freetype2 /usr/local/include
ln -sf /usr/local/freetype/include/ft2build.h /usr/local/include
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Freetype_version}

echo "[+] installing ${Curl_version}"
tarj_cd ${Curl_version}.tar.bz2 ${Curl_version}
./configure --prefix=/usr/local/curl --enable-ares --without-nss --with-ssl
make && make install
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Curl_version}
remove_error_Libcurl

curr_Pcre_version=`pcre-config --version`
if echo "${curr_Pcre_version}" | grep -vEqi '^8.';then
	echo "[+] installing ${Pcre_version}"
	tarj_cd ${Pcre_version}.tar.bz2 ${Pcre_version}
	./configure
	make && make install
	cd ${cur_dir}/src/
	rm -rf ${cur_dir}/src/${Pcre_version}
fi

echo "[+] installing ${Jemalloc_version}"
cd ${cur_dir}/src
tarj_cd ${Jemalloc_version}.tar.bz2 ${Jemalloc_version}
./configure
make && make install
ldconfig
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Jemalloc_version}

if /usr/bin/icu-config --version | grep '^3.'; then
	echo "[+] installing ${Libicu4c_version}"
	cd ${cur_dir}/src
	download_files ${download_Mirror}/lib/icu4c/${Libicu4c_version}-src.tgz ${Libicu4c_version}-src.tgz
	tar_cd ${Libicu4c_version}-src.tgz icu/source
	./configure --prefix=/usr
	make && make install
	cd ${cur_dir}/src/
	rm -rf ${cur_dir}/src/icu
fi

echo "[+] installing ${Boost_version}"
cd ${cur_dir}/src
download_files ${download_Mirror}/lib/boost/${Boost_version}.tar.bz2 ${Boost_version}.tar.bz2
tarj_cd ${Boost_version}.tar.bz2 ${Boost_version}
./bootstrap.sh
./b2
./b2 install
cd ${cur_dir}/src/
rm -rf ${cur_dir}/src/${Boost_version}

    if [ "${Is_64bit}" = "y" ] ; then
        ln -sf /usr/lib/x86_64-linux-gnu/libpng* /usr/lib/
        ln -sf /usr/lib/x86_64-linux-gnu/libjpeg* /usr/lib/
    else
        ln -sf /usr/lib/i386-linux-gnu/libpng* /usr/lib/
        ln -sf /usr/lib/i386-linux-gnu/libjpeg* /usr/lib/
        ln -sf /usr/include/i386-linux-gnu/asm /usr/include/asm
    fi
    ulimit -v unlimited
    if [ `grep -L "/lib"    '/etc/ld.so.conf'` ]; then
        echo "/lib" >> /etc/ld.so.conf
    fi
    if [ `grep -L '/usr/lib'    '/etc/ld.so.conf'` ]; then
        echo "/usr/lib" >> /etc/ld.so.conf
    fi
    if [ -d "/usr/lib64" ] && [ `grep -L '/usr/lib64'    '/etc/ld.so.conf'` ]; then
        echo "/usr/lib64" >> /etc/ld.so.conf
    fi
    if [ `grep -L '/usr/local/lib'    '/etc/ld.so.conf'` ]; then
        echo "/usr/local/lib" >> /etc/ld.so.conf
    fi
    ldconfig
    cat >>/etc/security/limits.conf<<eof
* soft nproc 65535
* hard nproc 65535
* soft nofile 65535
* hard nofile 65535
eof

    echo "fs.file-max=65535" >> /etc/sysctl.conf
	
apt-get purge -y mysql-client mysql-server mysql-common mysql-server-core-5.5 mysql-client-5.5
rm -f /etc/my.cnf
rm -rf /etc/mysql/

###安装mysql 5.7
    echo "[+] installing ${Mysql_version}..."
    rm -f /etc/my.cnf
    tar_cd ${Mysql_version}.tar.gz ${Mysql_version}
    cmake -DCMAKE_INSTALL_PREFIX=/usr/local/mysql -DSYSCONFDIR=/etc -DWITH_MYISAM_STORAGE_ENGINE=1 -DWITH_INNOBASE_STORAGE_ENGINE=1 -DWITH_PARTITION_STORAGE_ENGINE=1 -DWITH_FEDERATED_STORAGE_ENGINE=1 -DEXTRA_CHARSETS=all -DDEFAULT_CHARSET=utf8mb4 -DDEFAULT_COLLATION=utf8mb4_general_ci -DWITH_EMBEDDED_SERVER=1 -DENABLED_LOCAL_INFILE=1 ${mysql55MAOpt}
    make && make install

    groupadd mysql
    useradd -s /sbin/nologin -M -g mysql mysql

    cat > /etc/my.cnf<<EOF
[client]
#password   = your_password
port        = 3306
socket      = /tmp/mysql.sock

[mysqld]
port        = 3306
socket      = /tmp/mysql.sock
datadir = ${mysql_data_dir}
skip-external-locking
key_buffer_size = 16M
max_allowed_packet = 1M
table_open_cache = 64
sort_buffer_size = 512K
net_buffer_length = 8K
read_buffer_size = 256K
read_rnd_buffer_size = 512K
myisam_sort_buffer_size = 8M
thread_cache_size = 8
query_cache_size = 8M
tmp_table_size = 16M
performance_schema_max_table_instances = 500

explicit_defaults_for_timestamp = true
#skip-networking
max_connections = 500
max_connect_errors = 100
open_files_limit = 65535

log-bin=mysql-bin
binlog_format=mixed
server-id   = 1
expire_logs_days = 10
early-plugin-load = ""

#loose-innodb-trx=0
#loose-innodb-locks=0
#loose-innodb-lock-waits=0
#loose-innodb-cmp=0
#loose-innodb-cmp-per-index=0
#loose-innodb-cmp-per-index-reset=0
#loose-innodb-cmp-reset=0
#loose-innodb-cmpmem=0
#loose-innodb-cmpmem-reset=0
#loose-innodb-buffer-page=0
#loose-innodb-buffer-page-lru=0
#loose-innodb-buffer-pool-stats=0
#loose-innodb-metrics=0
#loose-innodb-ft-default-stopword=0
#loose-innodb-ft-inserted=0
#loose-innodb-ft-deleted=0
#loose-innodb-ft-being-deleted=0
#loose-innodb-ft-config=0
#loose-innodb-ft-index-cache=0
#loose-innodb-ft-index-table=0
#loose-innodb-sys-tables=0
#loose-innodb-sys-tablestats=0
#loose-innodb-sys-indexes=0
#loose-innodb-sys-columns=0
#loose-innodb-sys-fields=0
#loose-innodb-sys-foreign=0
#loose-innodb-sys-foreign-cols=0

default_storage_engine = InnoDB
#innodb_data_home_dir = ${mysql_data_dir}
#innodb_data_file_path = ibdata1:10M:autoextend
#innodb_log_group_home_dir = ${mysql_data_dir}
#innodb_buffer_pool_size = 16M
#innodb_log_file_size = 5M
#innodb_log_buffer_size = 8M
#innodb_flush_log_at_trx_commit = 1
#innodb_lock_wait_timeout = 50

[mysqldump]
quick
max_allowed_packet = 16M

[mysql]
no-auto-rehash

[myisamchk]
key_buffer_size = 20M
sort_buffer_size = 20M
read_buffer = 2M
write_buffer = 2M

[mysqlhotcopy]
interactive-timeout
EOF

    if [ "${installInnodb}" = "y" ]; then
        sed -i 's:^#innodb:innodb:g' /etc/my.cnf
    else
        sed -i '/^default_storage_engine/d' /etc/my.cnf
        sed -i '/skip-external-locking/i\innodb=OFF\nignore-builtin-innodb\nskip-innodb\ndefault_storage_engine = MyISAM\ndefault_tmp_storage_engine = MyISAM' /etc/my.cnf
        sed -i 's/^#loose-innodb/loose-innodb/g' /etc/my.cnf
    fi
    if [[ ${MemTotal} -gt 1024 && ${MemTotal} -lt 2048 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 32M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 128#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 768K#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 768K#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 8M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 16#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 16M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 32M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 128M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 32M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 1000" /etc/my.cnf
    elif [[ ${MemTotal} -ge 2048 && ${MemTotal} -lt 4096 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 64M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 256#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 1M#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 1M#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 16M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 32#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 32M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 64M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 256M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 64M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 2000" /etc/my.cnf
    elif [[ ${MemTotal} -ge 4096 && ${MemTotal} -lt 8192 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 128M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 512#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 2M#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 2M#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 32M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 64#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 64M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 64M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 512M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 128M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 4000" /etc/my.cnf
    elif [[ ${MemTotal} -ge 8192 && ${MemTotal} -lt 16384 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 256M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 1024#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 4M#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 4M#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 64M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 128#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 128M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 128M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 1024M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 256M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 6000" /etc/my.cnf
    elif [[ ${MemTotal} -ge 16384 && ${MemTotal} -lt 32768 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 512M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 2048#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 8M#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 8M#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 128M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 256#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 256M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 256M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 2048M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 512M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 8000" /etc/my.cnf
    elif [[ ${MemTotal} -ge 32768 ]]; then
        sed -i "s#^key_buffer_size.*#key_buffer_size = 1024M#" /etc/my.cnf
        sed -i "s#^table_open_cache.*#table_open_cache = 4096#" /etc/my.cnf
        sed -i "s#^sort_buffer_size.*#sort_buffer_size = 16M#" /etc/my.cnf
        sed -i "s#^read_buffer_size.*#read_buffer_size = 16M#" /etc/my.cnf
        sed -i "s#^myisam_sort_buffer_size.*#myisam_sort_buffer_size = 256M#" /etc/my.cnf
        sed -i "s#^thread_cache_size.*#thread_cache_size = 512#" /etc/my.cnf
        sed -i "s#^query_cache_size.*#query_cache_size = 512M#" /etc/my.cnf
        sed -i "s#^tmp_table_size.*#tmp_table_size = 512M#" /etc/my.cnf
        sed -i "s#^innodb_buffer_pool_size.*#innodb_buffer_pool_size = 4096M#" /etc/my.cnf
        sed -i "s#^innodb_log_file_size.*#innodb_log_file_size = 1024M#" /etc/my.cnf
        sed -i "s#^performance_schema_max_table_instances.*#performance_schema_max_table_instances = 10000" /etc/my.cnf
    fi
    if [ -d "${mysql_data_dir}" ]; then
        rm -rf ${mysql_data_dir}/*
    else
        mkdir -p ${mysql_data_dir}
    fi
    chown -R mysql:mysql ${mysql_data_dir}
    /usr/local/mysql/bin/mysqld --initialize-insecure --basedir=/usr/local/mysql --datadir=${mysql_data_dir} --user=mysql
    chgrp -R mysql /usr/local/mysql/.
    \cp support-files/mysql.server /etc/init.d/mysql
    chmod 755 /etc/init.d/mysql

    cat > /etc/ld.so.conf.d/mysql.conf<<EOF
    /usr/local/mysql/lib
    /usr/local/lib
EOF
    ldconfig
    ln -sf /usr/local/mysql/lib/mysql /usr/lib/mysql
    ln -sf /usr/local/mysql/include/mysql /usr/include/mysql

    ##mysql_Sec_setting
	if [ -d "/proc/vz" ];then
        ulimit -s unlimited
    fi

    startUp mysql
    /etc/init.d/mysql start

    ln -sf /usr/local/mysql/bin/mysql /usr/bin/mysql
    ln -sf /usr/local/mysql/bin/mysqldump /usr/bin/mysqldump
    ln -sf /usr/local/mysql/bin/myisamchk /usr/bin/myisamchk
    ln -sf /usr/local/mysql/bin/mysqld_safe /usr/bin/mysqld_safe
    ln -sf /usr/local/mysql/bin/mysqlcheck /usr/bin/mysqlcheck

    /usr/local/mysql/bin/mysqladmin -u root password "${DB_Root_password}"
    if [ $? -ne 0 ]; then
        echo "failed, try other way..."
        cat >~/.emptymy.cnf<<EOF
[client]
user=root
password=''
EOF
        if [ "${DBSelect}" = "6" ] || echo "${mysql_version}" | grep -Eqi '^5.7.'; then
            /usr/local/mysql/bin/mysql --defaults-file=~/.emptymy.cnf -e "SET PASSWORD FOR 'root'@'localhost' = PASSWORD('${DB_Root_password}');"
            [ $? -eq 0 ] && echo "set password Sucessfully." || echo "set password failed!"
        else
            /usr/local/mysql/bin/mysql --defaults-file=~/.emptymy.cnf -e "UPDATE mysql.user SET password=PASSWORD('${DB_Root_password}') WHERE User='root';"
            [ $? -eq 0 ] && echo "set password Sucessfully." || echo "set password failed!"
            /usr/local/mysql/bin/mysql --defaults-file=~/.emptymy.cnf -e "FLUSH PRIVILEGES;"
            [ $? -eq 0 ] && echo "FLUSH PRIVILEGES Sucessfully." || echo "FLUSH PRIVILEGES failed!"
        fi
        rm -f ~/.emptymy.cnf
    fi
    /etc/init.d/mysql restart

    make_temp_mycnf "${DB_Root_password}"
    do_Query ""
    if [ $? -eq 0 ]; then
        echo "OK, mysql root password correct."
    fi
    echo "Update root password..."
    if [ "${DBSelect}" = "6" ] || echo "${mysql_version}" | grep -Eqi '^5.7.'; then
        do_Query "UPDATE mysql.user SET authentication_string=PASSWORD('${DB_Root_password}') WHERE User='root';"
    else
        do_Query "UPDATE mysql.user SET password=PASSWORD('${DB_Root_password}') WHERE User='root';"
    fi
    [ $? -eq 0 ] && echo " ... Success." || echo " ... Failed!"
    echo "remove anonymous users..."
    do_Query "DELETE FROM mysql.user WHERE User='';"
    do_Query "DROP USER ''@'%';"
    [ $? -eq 0 ] && echo " ... Success." || echo " ... Failed!"
    echo "Disallow root login remotely..."
    do_Query "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"
    [ $? -eq 0 ] && echo " ... Success." || echo " ... Failed!"
    echo "remove test database..."
    do_Query "DROP DATABASE test;"
    [ $? -eq 0 ] && echo " ... Success." || echo " ... Failed!"
    echo "Reload privilege tables..."
    do_Query "FLUSH PRIVILEGES;"
    [ $? -eq 0 ] && echo " ... Success." || echo " ... Failed!"

    /etc/init.d/mysql restart
    /etc/init.d/mysql stop
	if [ -s ~/.my.cnf ]; then
        rm -f ~/.my.cnf
    fi
    if [ -s /tmp/.mysql.tmp ]; then
        rm -f /tmp/.mysql.tmp
    fi
### 安装php7.1
    echo "[+] installing ${php_version}"
    if uname -m | grep -Eqi "arm"; then
        Is_ARM='y'
    fi
    if [[ "${DISTRO}" = "CentOS" && "${Is_ARM}" = "y" ]];then
        with_curl='--with-curl=/usr/local/curl'
    else
        with_curl='--with-curl'
    fi
    tarj_cd ${php_version}.tar.bz2 ${php_version}
    
    ./configure --prefix=/usr/local/php --with-config-file-path=/usr/local/php/etc --with-config-file-scan-dir=/usr/local/php/conf.d --enable-fpm --with-fpm-user=www --with-fpm-group=www --enable-mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --with-iconv-dir --with-freetype-dir=/usr/local/freetype --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir=/usr --enable-xml --disable-rpath --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization ${with_curl} --enable-mbregex --enable-mbstring --enable-intl --enable-pcntl --with-mcrypt --enable-ftp --with-gd --enable-gd-native-ttf --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --with-gettext --disable-fileinfo --enable-opcache --with-xsl ${php_modules_options}
   
    make ZEND_EXTRA_LIBS='-liconv'
    make install

    ln -sf /usr/local/php/bin/php /usr/bin/php
    ln -sf /usr/local/php/bin/phpize /usr/bin/phpize
    ln -sf /usr/local/php/bin/pear /usr/bin/pear
    ln -sf /usr/local/php/bin/pecl /usr/bin/pecl
    ln -sf /usr/local/php/sbin/php-fpm /usr/bin/php-fpm

    echo "Copy new php configure file..."
    mkdir -p /usr/local/php/{etc,conf.d}
    \cp php.ini-production /usr/local/php/etc/php.ini

    cd ${cur_dir}
    # php extensions
    echo "Modify php.ini......"
    sed -i 's/post_max_size =.*/post_max_size = 50M/g' /usr/local/php/etc/php.ini
    sed -i 's/upload_max_filesize =.*/upload_max_filesize = 50M/g' /usr/local/php/etc/php.ini
    sed -i 's/;date.timezone =.*/date.timezone = PRC/g' /usr/local/php/etc/php.ini
    sed -i 's/short_open_tag =.*/short_open_tag = On/g' /usr/local/php/etc/php.ini
    sed -i 's/;cgi.fix_pathinfo=.*/cgi.fix_pathinfo=0/g' /usr/local/php/etc/php.ini
    sed -i 's/max_execution_time =.*/max_execution_time = 300/g' /usr/local/php/etc/php.ini
    sed -i 's/disable_functions =.*/disable_functions = passthru,exec,system,chroot,scandir,chgrp,chown,shell_exec,proc_open,proc_get_status,popen,ini_alter,ini_restore,dl,openlog,syslog,readlink,symlink,popepassthru,stream_socket_server/g' /usr/local/php/etc/php.ini
	
    pear config-set php_ini /usr/local/php/etc/php.ini
    pecl config-set php_ini /usr/local/php/etc/php.ini
    curl -sS --connect-timeout 10 -m 60 https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
    if [ $? -eq 0 ]; then
        echo "Composer install successfully."
    else
        echo "Composer install failed!"
    fi

    echo "install ZendGuardLoader for PHP 7.1..."
    echo "unavailable now."

    echo "Write ZendGuardLoader to php.ini..."
    cat >/usr/local/php/conf.d/002-zendguardloader.ini<<EOF
[Zend ZendGuard Loader]
;php7.1 do not support zendguardloader,after support you can uncomment the following line.
;zend_extension=/usr/local/zend/ZendGuardLoader.so
;zend_loader.enable=1
;zend_loader.disable_licensing=0
;zend_loader.obfuscation_level_support=3
;zend_loader.license_path=
EOF

if [ "${stack}" = "lnmp" ]; then
    echo "createing new php-fpm configure file..."
    cat >/usr/local/php/etc/php-fpm.conf<<EOF
[global]
pid = /usr/local/php/var/run/php-fpm.pid
error_log = /usr/local/php/var/log/php-fpm.log
log_level = notice

[www]
listen = /tmp/php-cgi.sock
listen.backlog = -1
listen.allowed_clients = 127.0.0.1
listen.owner = www
listen.group = www
listen.mode = 0666
user = www
group = www
pm = dynamic
pm.max_children = 10
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 6
request_terminate_timeout = 100
request_slowlog_timeout = 0
slowlog = var/log/slow.log
EOF

    echo "Copy php-fpm init.d file..."
    \cp ${cur_dir}/src/${php_version}/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm
    chmod +x /etc/init.d/php-fpm
fi
	if [[ ${MemTotal} -gt 1024 && ${MemTotal} -le 2048 ]]; then
        sed -i "s#pm.max_children.*#pm.max_children = 20#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.start_servers.*#pm.start_servers = 10#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.min_spare_servers.*#pm.min_spare_servers = 10#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.max_spare_servers.*#pm.max_spare_servers = 20#" /usr/local/php/etc/php-fpm.conf
    elif [[ ${MemTotal} -gt 2048 && ${MemTotal} -le 4096 ]]; then
        sed -i "s#pm.max_children.*#pm.max_children = 40#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.start_servers.*#pm.start_servers = 20#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.min_spare_servers.*#pm.min_spare_servers = 20#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.max_spare_servers.*#pm.max_spare_servers = 40#" /usr/local/php/etc/php-fpm.conf
    elif [[ ${MemTotal} -gt 4096 && ${MemTotal} -le 8192 ]]; then
        sed -i "s#pm.max_children.*#pm.max_children = 60#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.start_servers.*#pm.start_servers = 30#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.min_spare_servers.*#pm.min_spare_servers = 30#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.max_spare_servers.*#pm.max_spare_servers = 60#" /usr/local/php/etc/php-fpm.conf
    elif [[ ${MemTotal} -gt 8192 ]]; then
        sed -i "s#pm.max_children.*#pm.max_children = 80#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.start_servers.*#pm.start_servers = 40#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.min_spare_servers.*#pm.min_spare_servers = 40#" /usr/local/php/etc/php-fpm.conf
        sed -i "s#pm.max_spare_servers.*#pm.max_spare_servers = 80#" /usr/local/php/etc/php-fpm.conf
    fi
	
###安装nginx
	echo "[+] installing ${Nginx_version}... "
    groupadd www
    useradd -s /sbin/nologin -g www www

    if [ "${enable_nginx_openssl}" = 'y' ]; then
        cd ${cur_dir}/src
        download_files ${download_Mirror}/lib/openssl/${Openssl_version}.tar.gz ${Openssl_version}.tar.gz
        [[ -d "${Openssl_version}" ]] && rm -rf ${Openssl_version}
        tar zxf ${Openssl_version}.tar.gz
        Nginx_With_Openssl="--with-openssl=${cur_dir}/src/${Openssl_version}"
    fi
    tar_cd ${Nginx_version}.tar.gz ${Nginx_version}
    if echo ${Nginx_version} | grep -Eqi 'nginx-[0-1].[5-8].[0-9]' || echo ${Nginx_version} | grep -Eqi 'nginx-1.9.[1-4]$'; then
        ./configure --user=www --group=www --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module --with-http_spdy_module --with-http_gzip_static_module --with-ipv6 --with-http_sub_module ${Nginx_With_Openssl} ${NginxMAOpt} ${nginx_modules_options}
    else
        ./configure --user=www --group=www --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module --with-http_v2_module --with-http_gzip_static_module --with-ipv6 --with-http_sub_module ${Nginx_With_Openssl} ${NginxMAOpt} ${nginx_modules_options}
    fi
    make && make install
    cd ../

    ln -sf /usr/local/nginx/sbin/nginx /usr/bin/nginx

    rm -f /usr/local/nginx/conf/nginx.conf
    cd ${cur_dir}
    if [ "${stack}" = "lnmpa" ]; then
        \cp conf/nginx_a.conf /usr/local/nginx/conf/nginx.conf
        \cp conf/proxy.conf /usr/local/nginx/conf/proxy.conf
    else
        \cp conf/nginx.conf /usr/local/nginx/conf/nginx.conf
    fi
    \cp conf/rewrite/dabr.conf /usr/local/nginx/conf/dabr.conf
    \cp conf/rewrite/discuz.conf /usr/local/nginx/conf/discuz.conf
    \cp conf/rewrite/sablog.conf /usr/local/nginx/conf/sablog.conf
    \cp conf/rewrite/typecho.conf /usr/local/nginx/conf/typecho.conf
    \cp conf/rewrite/typecho2.conf /usr/local/nginx/conf/typecho2.conf
    \cp conf/rewrite/wordpress.conf /usr/local/nginx/conf/wordpress.conf
    \cp conf/rewrite/discuzx.conf /usr/local/nginx/conf/discuzx.conf
    \cp conf/rewrite/none.conf /usr/local/nginx/conf/none.conf
    \cp conf/rewrite/wp2.conf /usr/local/nginx/conf/wp2.conf
    \cp conf/rewrite/phpwind.conf /usr/local/nginx/conf/phpwind.conf
    \cp conf/rewrite/shopex.conf /usr/local/nginx/conf/shopex.conf
    \cp conf/rewrite/dedecms.conf /usr/local/nginx/conf/dedecms.conf
    \cp conf/rewrite/drupal.conf /usr/local/nginx/conf/drupal.conf
    \cp conf/rewrite/ecshop.conf /usr/local/nginx/conf/ecshop.conf
    \cp conf/pathinfo.conf /usr/local/nginx/conf/pathinfo.conf
    \cp conf/enable-php.conf /usr/local/nginx/conf/enable-php.conf
    \cp conf/enable-php-pathinfo.conf /usr/local/nginx/conf/enable-php-pathinfo.conf
    \cp conf/proxy-pass-php.conf /usr/local/nginx/conf/proxy-pass-php.conf
    \cp conf/enable-ssl-example.conf /usr/local/nginx/conf/enable-ssl-example.conf

    mkdir -p ${default_website_dir}
    chmod +w ${default_website_dir}
    mkdir -p /home/wwwlogs
    chmod 777 /home/wwwlogs

    chown -R www:www ${default_website_dir}

    mkdir /usr/local/nginx/conf/vhost

    if [ "${default_website_dir}" != "/home/wwwroot/default" ]; then
        sed -i "s#/home/wwwroot/default#${default_website_dir}#g" /usr/local/nginx/conf/nginx.conf
    fi

    
    cat >${default_website_dir}/.user.ini<<EOF
open_basedir=${default_website_dir}:/tmp/:/proc/
EOF
    chmod 644 ${default_website_dir}/.user.ini
    chattr +i ${default_website_dir}/.user.ini
    cat >>/usr/local/nginx/conf/fastcgi.conf<<EOF
fastcgi_param PHP_ADMIN_VALUE "open_basedir=$document_root/:/tmp/:/proc/";
EOF

    \cp init.d/init.d.nginx /etc/init.d/nginx
    chmod +x /etc/init.d/nginx
	
	echo "createe PHP info Tool..."
    cat >${default_website_dir}/phpinfo.php<<eof
<?php
phpinfo();
?>
eof

    echo "Copy PHP Prober..."
    cd ${cur_dir}/src
    tar zxf p.tar.gz
    \cp p.php ${default_website_dir}/p.php

    \cp ${cur_dir}/conf/index.html ${default_website_dir}/index.html
    \cp ${cur_dir}/conf/lnmp.gif ${default_website_dir}/lnmp.gif

    if [ ${PHPSelect} -ge 4 ]; then
        echo "Copy Opcache Control Panel..."
        \cp ${cur_dir}/conf/ocp.php ${default_website_dir}/ocp.php
    fi
    echo "============================install PHPMyAdmin================================="
    [[ -d ${default_website_dir}/phpmyadmin ]] && rm -rf ${default_website_dir}/phpmyadmin
    tar jxf ${PhpMyAdmin_version}.tar.bz2
    mv ${PhpMyAdmin_version} ${default_website_dir}/phpmyadmin
    \cp ${cur_dir}/conf/config.inc.php ${default_website_dir}/phpmyadmin/config.inc.php
    sed -i 's/LNMPORG/LNMP.org'$RANDOM'VPSer.net/g' ${default_website_dir}/phpmyadmin/config.inc.php
    mkdir ${default_website_dir}/phpmyadmin/{upload,save}
    chmod 755 -R ${default_website_dir}/phpmyadmin/
    chown www:www -R ${default_website_dir}/phpmyadmin/
    echo "============================phpMyAdmin install completed======================="
	
### 加入iptables规则	
	if [ -s /sbin/iptables ]; then
        /sbin/iptables -I INPUT 1 -i lo -j ACCEPT
        /sbin/iptables -I INPUT 2 -m state --state ESTABLISHED,RELATED -j ACCEPT
        /sbin/iptables -I INPUT 3 -p tcp --dport 22 -j ACCEPT
        /sbin/iptables -I INPUT 4 -p tcp --dport 80 -j ACCEPT
        /sbin/iptables -I INPUT 5 -p tcp --dport 443 -j ACCEPT
        /sbin/iptables -I INPUT 6 -p tcp --dport 3306 -j DROP
        /sbin/iptables -I INPUT 7 -p icmp -m icmp --icmp-type 8 -j ACCEPT
        if [ "$PM" = "yum" ]; then
            service iptables save
            if [ -s /usr/sbin/firewalld ]; then
                systemctl stop firewalld
                systemctl disable firewalld
            fi
        elif [ "$PM" = "apt" ]; then
            iptables-save > /etc/iptables.rules
            cat >/etc/network/if-post-down.d/iptables<<EOF
#!/bin/bash
iptables-save > /etc/iptables.rules
EOF
            chmod +x /etc/network/if-post-down.d/iptables
            cat >/etc/network/if-pre-up.d/iptables<<EOF
#!/bin/bash
iptables-restore < /etc/iptables.rules
EOF
            chmod +x /etc/network/if-pre-up.d/iptables
        fi
    fi
	
	echo "Add startup and starting LNMP..."
    \cp ${cur_dir}/conf/lnmp /bin/lnmp
    chmod +x /bin/lnmp
    startUp nginx
    #/etc/init.d/nginx start
    startUp mysql
    #/etc/init.d/mysql start
    startUp php-fpm
    #/etc/init.d/php-fpm start

	wget https://raw.githubusercontent.com/DuckLL/lnmp/master/lnmp.sh -O /etc/init.d/lnmp.sh && chmod +x /etc/init.d/lnmp.sh
	sed -i -e '/exit 0/a\/etc/init.d/lnmp.sh' /etc/rc.local
