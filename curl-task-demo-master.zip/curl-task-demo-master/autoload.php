<?php

require __DIR__ . '/config.php';
require __DIR__ . '/lib/console-func.php';
require __DIR__ . '/lib/FileLock.php';
require __DIR__ . '/lib/MultiProcess.php';
require __DIR__ . '/lib/SignalHandler.php';
require __DIR__ . '/lib/TaskProcess.php';