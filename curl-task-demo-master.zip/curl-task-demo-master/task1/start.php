<?php


// 生成数据
function task1_start($start, $end) {
	// var_dump($start);
	// var_dump($end);
	return range($start, $end);
}
